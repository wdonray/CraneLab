Thanks for buying one of my 3D Ship Models (-: This particular 3D model was reproduced from scanned drawings and photographs taking countless hours over several months.  

To enable import in various 3D applications the original 3D object was exported to various popular 3D file formats. Depending on 3D file format / application used, the 3D model's original surface & texture properties might get have been altered or lost.

This 3D model is based on an existing design launched in 1995 for Smit-Lloyd. After being operated by Seacor and Havila the the vessel continous to trade, currently under Chinese flag. 

